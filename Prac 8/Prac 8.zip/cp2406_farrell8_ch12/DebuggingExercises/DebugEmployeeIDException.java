package DebuggingExercises;

class DebugEmployeeIDException extends Exception
{
   DebugEmployeeIDException()
   {
      super();
   }
}


